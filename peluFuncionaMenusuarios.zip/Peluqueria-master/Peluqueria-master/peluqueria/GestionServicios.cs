﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace peluqueria
{
    public partial class GestionServicios : Form
    {
        public GestionServicios()
        {
            InitializeComponent();
            AsignarEventos();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void AsignarEventos()
        {
            // Cargar datos al iniciar
            this.Load += GestionServicios_Load;

            // Navegación de botones principales (Acciones)
            this.btnAnyadirServicio.Click += (s, e) => { 
                new AnyadirServicios().Show(); 
                this.Hide(); 
            };

            this.btnEditarServicio.Click += (s, e) => {
                // Si hay una fila seleccionada, pasamos el ID para editar directamente
                if (dtGrdVwServicios.SelectedRows.Count > 0)
                {
                    // Asumimos que la columna "id" existe o es la primera celda oculta.
                    // Depende de tu DTO, aquí intentamos obtener el objeto enlazado.
                    var servicio = dtGrdVwServicios.SelectedRows[0].DataBoundItem as ApiClient.ServicioDTO;
                    
                    // Nota: ServicioDTO original no tenía ID, si lo necesitas para editar, 
                    // asegúrate de añadir "public long id { get; set; }" en la clase ServicioDTO del ApiClient.
                    // Si no, abrimos el formulario vacío.
                    new EdicionServicios().Show(); 
                }
                else
                {
                    new EdicionServicios().Show();
                }
                this.Hide(); 
            };

            this.btnEliminarServicio.Click += (s, e) => { 
                new EliminarServicios().Show(); 
                this.Hide(); 
            };

            // Menú Lateral
            this.btnInicio.Click += (s, e) => { new Inicio().Show(); this.Hide(); };
            this.btnClientes.Click += (s, e) => { new Clientes().Show(); this.Hide(); };
            this.btnEmpleados.Click += (s, e) => { new Usuarios().Show(); this.Hide(); };
            this.logOutButton.Click += (s, e) => { Application.Exit(); };
        }

        private async void GestionServicios_Load(object sender, EventArgs e)
        {
            try
            {
                // CONEXIÓN CON JAVA: Obtener servicios reales
                List<ApiClient.ServicioDTO> servicios = await ApiClient.ObtenerServiciosAsync();
                
                dtGrdVwServicios.DataSource = servicios;
                
                // Ajustes visuales de la tabla
                if (dtGrdVwServicios.Columns["imageBase64"] != null) 
                    dtGrdVwServicios.Columns["imageBase64"].Visible = false; // Ocultar código de imagen largo
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar servicios: " + ex.Message);
            }
        }
    }
}