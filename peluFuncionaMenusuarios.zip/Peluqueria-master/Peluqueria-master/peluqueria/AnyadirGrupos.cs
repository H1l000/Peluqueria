﻿using System;
using System.Windows.Forms;

namespace peluqueria
{
    public partial class AnyadirGrupos : Form
    {
        public AnyadirGrupos()
        {
            InitializeComponent();
            AsignarEventos();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void AsignarEventos()
        {
            this.btnGuardarGrupo.Click += new EventHandler(btnGuardarGrupo_Click);

            // Navegación (CORREGIDO con this.Close())
            this.btnInicio.Click += (s, e) => { new Inicio().Show(); this.Close(); };
            this.btnClientes.Click += (s, e) => { new Clientes().Show(); this.Close(); };
            this.btnEmpleados.Click += (s, e) => { new Usuarios().Show(); this.Close(); }; 
            this.btnServicios.Click += (s, e) => { new GestionServicios().Show(); this.Close(); };
            this.logOutButton.Click += (s, e) => { new Login().Show(); this.Close(); };
        }

        private async void btnGuardarGrupo_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtBoxNombreGrupo.Text) ||
                string.IsNullOrWhiteSpace(txtBoxEmailGrupo.Text) ||
                string.IsNullOrWhiteSpace(txtBoxContraseñaContrasenyaGrupo.Text))
            {
                MessageBox.Show("Nombre, Email y Contraseña son obligatorios.", "Aviso");
                return;
            }

            bool exito = await ApiClient.RegistrarUsuarioAsync(
                txtBoxNombreGrupo.Text, 
                txtBoxEmailGrupo.Text,
                txtBoxContraseñaContrasenyaGrupo.Text,
                "user" 
            );

            if (exito)
            {
                MessageBox.Show($"Grupo registrado (como Usuario Estándar).", "Info");
                txtBoxNombreGrupo.Clear();
                txtBoxEmailGrupo.Clear();
                txtBoxContraseñaContrasenyaGrupo.Clear();
                // Si esta ventana se abre con ShowDialog(), se cierra sola al volver.
                // Si no, puedes añadir 'this.Close()' aquí para volver al selector.
            }
        }
    }
}