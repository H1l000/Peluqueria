using System;
using System.Windows.Forms;

namespace peluqueria
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            // CAMBIO IMPORTANTE: Arrancamos con mainMenu
            Application.Run(new mainMenu());
        }
    }
}