﻿using System;
using System.Windows.Forms;

namespace peluqueria
{
    public partial class EditarUsuarios : Form
    {
        private long idUsuario;

        public EditarUsuarios(long id)
        {
            InitializeComponent();
            this.idUsuario = id;
            AsignarEventos();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        public EditarUsuarios() : this(0) { }

        private void AsignarEventos()
        {
            this.Load += EditarUsuarios_Load;
            this.btnGuardarEdicionUsuario.Click += btnGuardarEdicionUsuario_Click;
            
            // Navegación (CORREGIDO con this.Close())
            this.btnInicio.Click += (s, e) => { new Inicio().Show(); this.Close(); };
            this.btnClientes.Click += (s, e) => { new Clientes().Show(); this.Close(); };
            this.btnEmpleados.Click += (s, e) => { new Usuarios().Show(); this.Close(); }; 
            this.btnServicios.Click += (s, e) => { new GestionServicios().Show(); this.Close(); };
            this.logOutButton.Click += (s, e) => { new Login().Show(); this.Close(); };
        }

        private async void EditarUsuarios_Load(object sender, EventArgs e)
        {
            if (idUsuario == 0) return;

            var usuario = await ApiClient.ObtenerUsuarioPorIdAsync(idUsuario);
            if (usuario != null)
            {
                txtBoxUsernameEdicionUsuario.Text = usuario.username;
                txtBoxEmailEdicionUsuario.Text = usuario.email;
                txtBoxNombreEdicionUsuario.Text = usuario.username; 
            }
        }

        private async void btnGuardarEdicionUsuario_Click(object sender, EventArgs e)
        {
            bool exito = await ApiClient.EditarUsuarioAsync(
                idUsuario,
                txtBoxUsernameEdicionUsuario.Text,
                txtBoxEmailEdicionUsuario.Text,
                txtBoxContraseñaContrasenyaEdicionUsuario.Text
            );

            if (exito)
            {
                MessageBox.Show("Usuario editado con éxito.");
                new Usuarios().Show();
                this.Close(); // CORREGIDO: Cierra la ventana actual al finalizar
            }
            else
            {
                MessageBox.Show("Error al editar usuario.");
            }
        }
    }
}