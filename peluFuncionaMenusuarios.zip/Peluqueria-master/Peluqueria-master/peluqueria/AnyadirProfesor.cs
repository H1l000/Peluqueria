﻿using System;
using System.Windows.Forms;

namespace peluqueria
{
    public partial class AnyadirProfesor : Form
    {
        public AnyadirProfesor()
        {
            InitializeComponent();
            AsignarEventos();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void AsignarEventos()
        {
            this.btnGuardarProfesor.Click += new EventHandler(btnGuardarProfesor_Click);

            // Menú (CORREGIDO con this.Close())
            this.btnInicio.Click += (s, e) => { new Inicio().Show(); this.Close(); };
            this.btnClientes.Click += (s, e) => { new Clientes().Show(); this.Close(); };
            this.btnServicios.Click += (s, e) => { new GestionServicios().Show(); this.Close(); };
            this.btnEmpleados.Click += (s, e) => { 
                 new Usuarios().Show(); 
                 this.Close(); // CORREGIDO
            };
            this.logOutButton.Click += (s, e) => { new Login().Show(); this.Close(); };
        }

        private async void btnGuardarProfesor_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtBoxNombreProfesor.Text) || 
                string.IsNullOrWhiteSpace(txtBoxEmailProfesor.Text) ||
                string.IsNullOrWhiteSpace(txtBoxContraseñaContrasenyaProfesor.Text))
            {
                MessageBox.Show("Todos los campos son obligatorios.", "Error");
                return;
            }

            bool exito = await ApiClient.RegistrarUsuarioAsync(
                txtBoxNombreProfesor.Text, 
                txtBoxEmailProfesor.Text,
                txtBoxContraseñaContrasenyaProfesor.Text,
                "admin" 
            );

            if (exito)
            {
                MessageBox.Show($"Profesor {txtBoxNombreProfesor.Text} registrado en el sistema.", "Éxito");
                txtBoxNombreProfesor.Clear();
                txtBoxEmailProfesor.Clear();
                txtBoxContraseñaContrasenyaProfesor.Clear();
                if(txtBoxUsernameProfesor != null) txtBoxUsernameProfesor.Clear(); 
            }
            else
            {
                MessageBox.Show("Error al registrar. Puede que el usuario o email ya existan.", "Error API");
            }
        }
    }
}