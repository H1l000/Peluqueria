﻿using System;
using System.Windows.Forms;

namespace peluqueria
{
    public partial class EliminarUsuario : Form
    {
        public EliminarUsuario()
        {
            InitializeComponent();
            AsignarEventos();
            this.StartPosition = FormStartPosition.CenterScreen;
            // Ajuste visual
            this.btnEmpleados.Text = "Usuarios";
        }

        private void AsignarEventos()
        {
            this.btnEliminarUsuario.Click += new EventHandler(btnEliminarUsuario_Click);

            // Menú Lateral
            this.btnInicio.Click += (s, e) => { new Inicio().Show(); this.Hide(); };
            this.btnClientes.Click += (s, e) => { new Clientes().Show(); this.Hide(); };
            this.btnEmpleados.Click += (s, e) => { new Usuarios().Show(); this.Hide(); }; // Volver a lista
            this.btnServicios.Click += (s, e) => { new GestionServicios().Show(); this.Hide(); };
            this.logOutButton.Click += (s, e) => { Application.Exit(); };
        }

        private async void btnEliminarUsuario_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtBoxIDEliminarUsuario.Text))
            {
                MessageBox.Show("Introduce el ID del usuario.");
                return;
            }

            if (!long.TryParse(txtBoxIDEliminarUsuario.Text, out long idUsuario))
            {
                MessageBox.Show("El ID debe ser numérico.");
                return;
            }

            DialogResult confirm = MessageBox.Show(
                $"¿Estás seguro de eliminar al usuario {idUsuario}?", 
                "Peligro", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (confirm == DialogResult.Yes)
            {
                // LLAMADA A JAVA
                bool exito = await ApiClient.EliminarUsuarioAsync(idUsuario);

                if (exito)
                {
                    MessageBox.Show("Usuario eliminado de la base de datos.");
                    new Usuarios().Show(); // Volver a la lista
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Error al eliminar. Verifica el ID o permisos.");
                }
            }
        }
    }
}