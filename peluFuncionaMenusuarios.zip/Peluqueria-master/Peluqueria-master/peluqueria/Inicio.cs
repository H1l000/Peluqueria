﻿using System;
using System.Windows.Forms;

namespace peluqueria
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();
            AsignarEventos();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void AsignarEventos()
        {
            this.Load += Inicio_Load;

            // Menú Lateral
            this.btnClientes.Click += (s, e) => { new Clientes().Show(); this.Hide(); };
            this.btnEmpleados.Click += (s, e) => { new Usuarios().Show(); this.Hide(); }; // Asumiendo que existe Usuarios.cs
            this.btnServicios.Click += (s, e) => { new GestionServicios().Show(); this.Hide(); };
            this.logOutButton.Click += (s, e) => { 
                ApiClient.TokenActual = null;
                new Login().Show(); 
                this.Hide(); 
            };
        }

        private async void Inicio_Load(object sender, EventArgs e)
        {
            // Cargar contadores reales desde Java
            try
            {
                // 1. Contar Clientes
                var clientes = await ApiClient.ObtenerClientesAsync();
                numClientes.Text = clientes.Count.ToString();

                // 2. Citas (Tu backend actual NO tiene entidad 'Cita' ni endpoint para ellas)
                // Por ahora lo dejamos en 0 o simulado hasta que actualices el Java.
                numCitas.Text = "0"; 
                
                // Limpiamos la tabla de citas por ahora
                dtgrdVwCitasHoy.DataSource = null; 
            }
            catch
            {
                numClientes.Text = "-";
            }
        }
    }
}