﻿using System;
using System.Windows.Forms;
using System.Diagnostics;
namespace peluqueria
{
    public partial class mainMenu : Form
    {
        public mainMenu()
        {
            InitializeComponent();
            AsignarEventos();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void AsignarEventos()
        {
            this.button1.Click += (s, e) => {
                new Inicio().Show();
                this.Hide();
            };

            this.pictbLogoInstagram.Click += (s, e) => {
                try { 
                    Process.Start(new ProcessStartInfo { FileName = "https://instagram.com", UseShellExecute = true }); 
                } catch { }
            };
        }

        private void mainMenu_Load(object sender, EventArgs e)
        {
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }
    }
}