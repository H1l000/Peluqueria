using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace peluqueria
{
    public static class ApiClient
    {
        // =========================================================
        // 1. CONFIGURACIÓN
        // =========================================================
        // Puerto 8081 (El de tu application.properties)
        private static readonly string BaseUrl = "http://localhost:8081/api";
        private static readonly HttpClient client = new HttpClient();

        // =========================================================
        // 2. DATOS DE SESIÓN
        // =========================================================
        public static string? TokenActual { get; set; }
        public static string? Username { get; set; }
        public static List<string>? Roles { get; set; }

        // =========================================================
        // 3. CLASES DTO (Adaptadas a tu Java)
        // =========================================================

        public class JwtResponse
        {
            // En tu Java se llama 'token', así que aquí también.
            public string? token { get; set; } 
            
            public string? type { get; set; }
            public string? username { get; set; }
            public List<string>? roles { get; set; }
            
            // NOTA: Tu Java NO envía email ni id, así que los quitamos de aquí 
            // para no confundirnos.
        }

        public class UsuarioDTO
        {
            public long id { get; set; }
            public string? username { get; set; }
            public string? email { get; set; }
            public string? password { get; set; }
            public List<string>? roles { get; set; }
        }

        public class ServicioDTO
        {
            public long id { get; set; }
            public string? nombre { get; set; }
            public string? descripcion { get; set; }
            public double precio { get; set; }
            public int duracionBloques { get; set; }
        }

        // =========================================================
        // 4. MÉTODOS DE AYUDA
        // =========================================================
        private static void ConfigurarAuth()
        {
            client.DefaultRequestHeaders.Authorization = null;
            if (!string.IsNullOrEmpty(TokenActual))
            {
                client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", TokenActual);
            }
        }

        // =========================================================
        // 5. AUTENTICACIÓN (LOGIN)
        // =========================================================

        public static async Task<bool> LoginAsync(string user, string pass)
        {
            try
            {
                var loginData = new { username = user, password = pass };
                string json = JsonConvert.SerializeObject(loginData);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                // Enviamos petición a Java (/auth/signin es lo que tienes en el Controller)
                var response = await client.PostAsync($"{BaseUrl}/auth/signin", content);

                if (response.IsSuccessStatusCode)
                {
                    var responseBody = await response.Content.ReadAsStringAsync();
                    
                    // Convertimos el JSON de Java a objetos C#
                    var datos = JsonConvert.DeserializeObject<JwtResponse>(responseBody);

                    // Verificamos si llegó el token correctamente
                    if (datos != null && !string.IsNullOrEmpty(datos.token))
                    {
                        TokenActual = datos.token;
                        Username = datos.username;
                        Roles = datos.roles;
                        return true;
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error conectando al servidor: " + ex.Message);
                return false;
            }
        }

        // =========================================================
        // 6. MÉTODOS DE REGISTRO
        // =========================================================

        public static async Task<bool> RegistrarUsuarioAsync(string username, string email, string password, string rol)
        {
            try
            {
                var registroData = new { username, email, password, role = new string[] { rol } };
                string json = JsonConvert.SerializeObject(registroData);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await client.PostAsync($"{BaseUrl}/auth/signup", content);
                return response.IsSuccessStatusCode;
            }
            catch { return false; }
        }

        // Wrapper para registrar admins
        public static async Task<bool> RegistrarAdminAsync(string u, string e, string p) 
        {
            return await RegistrarUsuarioAsync(u, e, p, "admin");
        }

        // =========================================================
        // 7. GESTIÓN DE USUARIOS (Recuperados para que no falle el compilador)
        // =========================================================

        public static async Task<List<UsuarioDTO>> ObtenerUsuariosAsync()
        {
            ConfigurarAuth();
            try {
                var res = await client.GetAsync($"{BaseUrl}/usuarios");
                if (res.IsSuccessStatusCode) 
                {
                    var json = await res.Content.ReadAsStringAsync();
                    var lista = JsonConvert.DeserializeObject<List<UsuarioDTO>>(json);
                    return lista ?? new List<UsuarioDTO>();
                }
                return new List<UsuarioDTO>();
            } catch { return new List<UsuarioDTO>(); }
        }

        // Alias para compatibilidad
        public static async Task<List<UsuarioDTO>> GetUsuariosAsync() => await ObtenerUsuariosAsync();
        
        public static async Task<List<UsuarioDTO>> ObtenerClientesAsync()
        {
             // Si tienes endpoint especifico usalo, si no, usa el general
             return await ObtenerUsuariosAsync(); 
        }

        public static async Task<UsuarioDTO?> ObtenerUsuarioPorIdAsync(long id) 
        {
            ConfigurarAuth();
            try {
                var res = await client.GetAsync($"{BaseUrl}/usuarios/{id}");
                if(res.IsSuccessStatusCode) return JsonConvert.DeserializeObject<UsuarioDTO>(await res.Content.ReadAsStringAsync());
                return null;
            } catch { return null; }
        }

        public static async Task<bool> EditarUsuarioAsync(long id, string u, string e, string? p = null)
        {
            ConfigurarAuth();
            try {
                var data = new { username = u, email = e, password = p };
                var content = new StringContent(JsonConvert.SerializeObject(data), Encoding.UTF8, "application/json");
                var res = await client.PutAsync($"{BaseUrl}/usuarios/{id}", content);
                return res.IsSuccessStatusCode;
            } catch { return false; }
        }

        public static async Task<bool> EliminarUsuarioAsync(long id)
        {
            ConfigurarAuth();
            try {
                var res = await client.DeleteAsync($"{BaseUrl}/usuarios/{id}");
                return res.IsSuccessStatusCode;
            } catch { return false; }
        }

        // =========================================================
        // 8. GESTIÓN DE SERVICIOS
        // =========================================================

        public static async Task<List<ServicioDTO>> ObtenerServiciosAsync()
        {
            ConfigurarAuth();
            try {
                var res = await client.GetAsync($"{BaseUrl}/servicios");
                if (res.IsSuccessStatusCode) return JsonConvert.DeserializeObject<List<ServicioDTO>>(await res.Content.ReadAsStringAsync()) ?? new List<ServicioDTO>();
                return new List<ServicioDTO>();
            } catch { return new List<ServicioDTO>(); }
        }

        public static async Task<ServicioDTO?> ObtenerServicioPorIdAsync(long id)
        {
            ConfigurarAuth();
            try {
                var res = await client.GetAsync($"{BaseUrl}/servicios/{id}");
                if(res.IsSuccessStatusCode) return JsonConvert.DeserializeObject<ServicioDTO>(await res.Content.ReadAsStringAsync());
                return null;
            } catch { return null; }
        }

        public static async Task<bool> CrearServicioAsync(ServicioDTO s)
        {
            ConfigurarAuth();
            try {
                var content = new StringContent(JsonConvert.SerializeObject(s), Encoding.UTF8, "application/json");
                var res = await client.PostAsync($"{BaseUrl}/servicios", content);
                return res.IsSuccessStatusCode;
            } catch { return false; }
        }

        public static async Task<bool> EditarServicioAsync(long id, ServicioDTO s)
        {
            ConfigurarAuth();
            try {
                var content = new StringContent(JsonConvert.SerializeObject(s), Encoding.UTF8, "application/json");
                var res = await client.PutAsync($"{BaseUrl}/servicios/{id}", content);
                return res.IsSuccessStatusCode;
            } catch { return false; }
        }

        public static async Task<bool> EliminarServicioAsync(long id)
        {
            ConfigurarAuth();
            try {
                var res = await client.DeleteAsync($"{BaseUrl}/servicios/{id}");
                return res.IsSuccessStatusCode;
            } catch { return false; }
        }
    }
}