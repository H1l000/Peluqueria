﻿using System;
using System.Windows.Forms;

namespace peluqueria
{
    public partial class EditarClientes : Form
    {
        private long idCliente; // Guardamos el ID del cliente que estamos editando

        // Constructor modificado para recibir el ID
        public EditarClientes(long id)
        {
            InitializeComponent();
            this.idCliente = id;
            AsignarEventos();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        // Constructor por defecto (por si acaso, aunque no debería usarse sin ID)
        public EditarClientes() : this(0) { }

        private void AsignarEventos()
        {
            this.Load += EditarClientes_Load;
            this.btnGuardarCliente.Click += new EventHandler(btnGuardarCliente_Click);
            
            // Navegación
            this.btnClientes.Click += (s, e) => { new Clientes().Show(); this.Hide(); };
            this.logOutButton.Click += (s, e) => { Application.Exit(); };
        }

        private async void EditarClientes_Load(object sender, EventArgs e)
        {
            if (idCliente == 0) return;

            // CARGAR DATOS DE JAVA AL ABRIR
            var usuario = await ApiClient.ObtenerUsuarioPorIdAsync(idCliente);
            if (usuario != null)
            {
                txtBoxUsernameEdicionCliente.Text = usuario.username;
                txtBoxEmailEdicionCliente.Text = usuario.email;
                // La contraseña no se suele cargar por seguridad, se deja en blanco
                // txtBoxNombreEdicionCliente -> OJO: El backend 'Usuario' no tiene campo 'Nombre', solo 'Username'.
                // Si quieres nombre real, tendrías que haberlo metido en 'Username' o tener un backend más complejo.
                txtBoxNombreEdicionCliente.Text = usuario.username; 
            }
            else
            {
                MessageBox.Show("No se encontró el cliente.", "Error");
                this.Close();
            }
        }

        private async void btnGuardarCliente_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtBoxUsernameEdicionCliente.Text) ||
                string.IsNullOrWhiteSpace(txtBoxEmailEdicionCliente.Text))
            {
                MessageBox.Show("Usuario y Email obligatorios.");
                return;
            }

            // ENVIAR CAMBIOS A JAVA
            bool exito = await ApiClient.EditarUsuarioAsync(
                idCliente,
                txtBoxUsernameEdicionCliente.Text,
                txtBoxEmailEdicionCliente.Text,
                txtBoxContraseñaContrasenyaEdicionCliente.Text // Si está vacío, Java suele ignorarlo (depende de tu lógica)
            );

            if (exito)
            {
                MessageBox.Show("Cliente actualizado correctamente.", "Éxito");
                new Clientes().Show(); // Volver a la lista
                this.Hide();
            }
            else
            {
                MessageBox.Show("Error al guardar cambios.", "Error API");
            }
        }
    }
}