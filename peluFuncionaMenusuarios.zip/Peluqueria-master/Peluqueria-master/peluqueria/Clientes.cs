﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace peluqueria
{
    public partial class Clientes : Form
    {
        public Clientes()
        {
            InitializeComponent();
            AsignarEventos();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void AsignarEventos()
        {
            // Navegación
            this.btnAnyadirCliente.Click += (s, e) => { new AnyadirCliente().Show(); this.Hide(); };
            this.btnEditarCliente.Click += (s, e) => { new EditarClientes().Show(); this.Hide(); };
            this.btnEliminarCliente.Click += new EventHandler(btnEliminarCliente_Click);
            
            // Menú
            this.btnInicio.Click += (s, e) => { new Inicio().Show(); this.Hide(); };
            this.btnEmpleados.Click += (s, e) => { new AnyadirAdministradores().Show(); this.Hide(); }; // O a lista de usuarios
            this.btnServicios.Click += (s, e) => { new GestionServicios().Show(); this.Hide(); }; // Asumiendo que tienes esta pantalla
            this.logOutButton.Click += (s, e) => { 
                ApiClient.TokenActual = null; // Borrar token
                new Login().Show(); 
                this.Hide(); 
            };

            // Cargar datos al abrir la ventana
            this.Load += new EventHandler(Clientes_Load);
        }

        private async void Clientes_Load(object sender, EventArgs e)
        {
            try
            {
                // Llamada a la API real
                List<ApiClient.UsuarioDTO> listaClientes = await ApiClient.ObtenerClientesAsync();
                
                // Asignar a la tabla
                dtGrdVwClientes.DataSource = listaClientes;
                
                // Opcional: Ocultar columnas que no quieras ver (como password o roles complejos)
                // if (dtGrdVwClientes.Columns["password"] != null) dtGrdVwClientes.Columns["password"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudieron cargar los clientes: " + ex.Message);
            }
        }

        private async void btnEliminarCliente_Click(object sender, EventArgs e)
        {
            // Verificar si hay una fila seleccionada
            if (dtGrdVwClientes.SelectedRows.Count > 0)
            {
                // Obtener el ID del objeto seleccionado
                // Nota: Depende de cómo el DataGridView mapee el objeto. 
                // Asumimos que la columna 0 o la propiedad "id" está disponible.
                var clienteSeleccionado = dtGrdVwClientes.SelectedRows[0].DataBoundItem as ApiClient.UsuarioDTO;

                if (clienteSeleccionado != null)
                {
                    DialogResult result = MessageBox.Show($"¿Eliminar a {clienteSeleccionado.username}?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (result == DialogResult.Yes)
                    {
                        bool eliminado = await ApiClient.EliminarUsuarioAsync(clienteSeleccionado.id);
                        if (eliminado)
                        {
                            MessageBox.Show("Cliente eliminado.");
                            Clientes_Load(null, null); // Recargar la tabla
                        }
                        else
                        {
                            MessageBox.Show("No se pudo eliminar (verifica permisos o si el usuario tiene citas).");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Selecciona la fila completa de un cliente primero.", "Aviso");
            }
        }

        private void panelDGVClientes_Paint(object sender, PaintEventArgs e) { }
    }
}