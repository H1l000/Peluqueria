﻿using System;
using System.Windows.Forms;

namespace peluqueria
{
    public partial class EleccionAnyadirTipoUsuarios : Form
    {
        public EleccionAnyadirTipoUsuarios()
        {
            InitializeComponent();
            AsignarEventos();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void AsignarEventos()
        {
            // --- Clic en las imágenes grandes ---
            // Abre "AnyadirAdministradores.cs"
            this.imgAnyadirAdministrador.Click += (s, e) => { new AnyadirAdministradores().Show(); this.Hide(); };
            
            // Abre "AnyadirGrupos.cs"
            this.imgAnyadirGrupo.Click += (s, e) => { new AnyadirGrupos().Show(); this.Hide(); };
            
            // Abre "AnyadirProfesor.cs"
            this.imAnyadirProfesor.Click += (s, e) => { new AnyadirProfesor().Show(); this.Hide(); };

            // --- Menú Lateral ---
            this.btnInicio.Click += (s, e) => { new Inicio().Show(); this.Hide(); };
            this.btnClientes.Click += (s, e) => { new Clientes().Show(); this.Hide(); };
            
            // Si le das a "Usuarios" (btnEmpleados), te lleva a la lista de usuarios
            this.btnEmpleados.Click += (s, e) => { new Usuarios().Show(); this.Hide(); }; 
            
            this.btnServicios.Click += (s, e) => { new GestionServicios().Show(); this.Hide(); }; // O AnyadirServicios
            this.logOutButton.Click += (s, e) => { new Login().Show(); this.Hide(); };
        }
    }
}