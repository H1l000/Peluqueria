﻿using System;
using System.Windows.Forms;

namespace peluqueria
{
    public partial class EliminarClientes : Form
    {
        public EliminarClientes()
        {
            InitializeComponent();
            AsignarEventos();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void AsignarEventos()
        {
            this.btnEliminarCliente.Click += new EventHandler(btnEliminarCliente_Click);

            // Navegación
            this.btnInicio.Click += (s, e) => { new Inicio().Show(); this.Hide(); };
            this.btnClientes.Click += (s, e) => { new Clientes().Show(); this.Hide(); };
            this.btnEmpleados.Click += (s, e) => { new Usuarios().Show(); this.Hide(); };
            this.btnServicios.Click += (s, e) => { new GestionServicios().Show(); this.Hide(); };
            this.logOutButton.Click += (s, e) => { new Login().Show(); this.Hide(); };
        }

        private async void btnEliminarCliente_Click(object sender, EventArgs e)
        {
            // 1. Validar que el usuario escribió algo
            if (string.IsNullOrWhiteSpace(txtBoxIDEliminarCliente.Text))
            {
                MessageBox.Show("Escribe el ID del cliente.", "Falta ID");
                return;
            }

            if (!long.TryParse(txtBoxIDEliminarCliente.Text, out long idCliente))
            {
                MessageBox.Show("El ID debe ser un número.", "Error");
                return;
            }

            // 2. Confirmar acción
            DialogResult respuesta = MessageBox.Show(
                $"¿Seguro que quieres eliminar al cliente {idCliente}?\nEsta acción es irreversible.", 
                "Confirmar", 
                MessageBoxButtons.YesNo, 
                MessageBoxIcon.Warning);

            if (respuesta == DialogResult.Yes)
            {
                // 3. Llamar al Backend
                bool exito = await ApiClient.EliminarUsuarioAsync(idCliente);

                if (exito)
                {
                    MessageBox.Show("Cliente eliminado correctamente.");
                    new Clientes().Show(); // Volver a la lista para ver que desapareció
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("No se pudo eliminar.\nVerifica que el ID exista o que tengas permisos de Admin.", "Error API");
                }
            }
        }
    }
}