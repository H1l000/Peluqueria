﻿using System;
using System.Windows.Forms;

namespace peluqueria
{
    public partial class EdicionServicios : Form
    {
        // Constructor que admite un ID opcional para precargar datos
        public EdicionServicios(long idServicioPreseleccionado = 0)
        {
            InitializeComponent();
            AsignarEventos();
            this.StartPosition = FormStartPosition.CenterScreen;

            // Si recibimos un ID al abrir la ventana, cargamos los datos
            if (idServicioPreseleccionado > 0)
            {
                txtBoxID.Text = idServicioPreseleccionado.ToString();
                CargarDatosServicio(idServicioPreseleccionado);
            }
        }

        private void AsignarEventos()
        {
            this.btnGuardarServicioEdit.Click += new EventHandler(btnGuardarServicioEdit_Click);

            // Evento: Al salir de la caja de texto ID, buscar automáticamente
            this.txtBoxID.Leave += (s, e) => {
                if (long.TryParse(txtBoxID.Text, out long id)) CargarDatosServicio(id);
            };

            // Menú Lateral
            this.btnInicio.Click += (s, e) => { new Inicio().Show(); this.Hide(); };
            
            // Si tienes un botón de usuarios, asegúrate de que se llame así en el diseño
            if(this.Controls.ContainsKey("btnUsuarios")) 
                this.Controls["btnUsuarios"].Click += (s, e) => { new Usuarios().Show(); this.Hide(); };
            
            this.btnServicios.Click += (s, e) => { new GestionServicios().Show(); this.Hide(); };
            this.logOutButton.Click += (s, e) => { new Login().Show(); this.Hide(); };
        }

        // Método auxiliar para rellenar los campos
        private async void CargarDatosServicio(long id)
        {
            var servicio = await ApiClient.ObtenerServicioPorIdAsync(id);
            if (servicio != null)
            {
                txtBoxTituloServicioEdit.Text = servicio.nombre;
                txtBoxDescripcionEdit.Text = servicio.descripcion;
                txtBoxBloqueDeTiempoEdit.Text = servicio.duracionBloques.ToString();
                // Si tienes precio en el diseño: txtBoxPrecio.Text = servicio.precio.ToString();
            }
            else
            {
                MessageBox.Show("Servicio no encontrado con ese ID.");
            }
        }

        private async void btnGuardarServicioEdit_Click(object sender, EventArgs e)
        {
            // 1. Validar ID
            if (!long.TryParse(txtBoxID.Text, out long id))
            {
                MessageBox.Show("El ID debe ser un número válido.", "Error");
                return;
            }

            // 2. Validar datos mínimos
            if (string.IsNullOrWhiteSpace(txtBoxTituloServicioEdit.Text))
            {
                MessageBox.Show("El título es obligatorio.");
                return;
            }

            int duracion = 0;
            int.TryParse(txtBoxBloqueDeTiempoEdit.Text, out duracion);

            // 3. Crear objeto DTO
            var servicioEditado = new ApiClient.ServicioDTO
            {
                id = id,
                nombre = txtBoxTituloServicioEdit.Text,
                descripcion = txtBoxDescripcionEdit.Text,
                duracionBloques = duracion,
                precio = 15.0 // Valor por defecto si no hay campo de precio
            };

            // 4. Llamar a la API
            bool exito = await ApiClient.EditarServicioAsync(id, servicioEditado);

            if (exito)
            {
                MessageBox.Show("Servicio actualizado correctamente.", "Éxito");
                new GestionServicios().Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Error al actualizar. Verifica que el ID exista en la base de datos.", "Error API");
            }
        }
    }
}