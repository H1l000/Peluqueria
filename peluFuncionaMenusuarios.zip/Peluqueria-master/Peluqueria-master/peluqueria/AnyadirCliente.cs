﻿using System;
using System.Windows.Forms;

namespace peluqueria
{
    public partial class AnyadirCliente : Form
    {
        public AnyadirCliente()
        {
            InitializeComponent();
            AsignarEventos();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void AsignarEventos()
        {
            this.btnGuardarCliente.Click += new EventHandler(btnGuardarCliente_Click);
            
            // Navegación
            this.btnInicio.Click += (s, e) => { new Inicio().Show(); this.Hide(); };
            // Asegúrate de que tienes el Formulario 'ListadoClientes' o 'Clientes'
            this.btnClientes.Click += (s, e) => { new Clientes().Show(); this.Hide(); }; 
            this.btnEmpleados.Click += (s, e) => { new Usuarios().Show(); this.Hide(); };
            this.btnServicios.Click += (s, e) => { new GestionServicios().Show(); this.Hide(); };
            this.logOutButton.Click += (s, e) => { new Login().Show(); this.Hide(); };
        }

        private async void btnGuardarCliente_Click(object sender, EventArgs e)
        {
            // Validaciones básicas
            if (string.IsNullOrWhiteSpace(txtBoxNombreCliente.Text) || 
                string.IsNullOrWhiteSpace(txtBoxEmailCliente.Text) ||
                string.IsNullOrWhiteSpace(txtBoxContraseñaContrasenyaCliente.Text))
            {
                MessageBox.Show("Usuario, Email y Contraseña son obligatorios.", "Atención");
                return;
            }

            // Nota visual para ti: Java ignora Dirección y Teléfono en el registro.
            // Los mandamos como "cliente" para que Java le ponga rol ROLE_CLIENTE.
            
            bool exito = await ApiClient.RegistrarUsuarioAsync(
                txtBoxNombreCliente.Text,
                txtBoxEmailCliente.Text,
                txtBoxContraseñaContrasenyaCliente.Text,
                "cliente" 
            );

            if (exito)
            {
                MessageBox.Show("Cliente registrado correctamente.\n(Nota: Dirección y Teléfono no se guardan por limitación del servidor backend).", "Éxito");
                
                // Limpiar campos
                txtBoxNombreCliente.Clear();
                txtBoxEmailCliente.Clear();
                txtBoxContraseñaContrasenyaCliente.Clear();
                txtBoxDireccion.Clear();
                txtBoxTelefono.Clear();
                
                // Opcional: Volver al listado
                // new Clientes().Show(); 
                // this.Hide();
            }
        }
    }
}