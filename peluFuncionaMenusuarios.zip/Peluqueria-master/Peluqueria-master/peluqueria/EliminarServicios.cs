﻿using System;
using System.Windows.Forms;

namespace peluqueria
{
    public partial class EliminarServicios : Form
    {
        public EliminarServicios()
        {
            InitializeComponent();
            AsignarEventos();
            this.StartPosition = FormStartPosition.CenterScreen;
            // Ajuste visual si tu botón se llama btnEmpleados pero el menú dice "Usuarios"
            this.btnEmpleados.Text = "Usuarios"; 
        }

        private void AsignarEventos()
        {
            this.btnEliminarServicio.Click += new EventHandler(btnEliminarServicio_Click);

            // Navegación del menú lateral
            this.btnInicio.Click += (s, e) => { new Inicio().Show(); this.Hide(); };
            this.btnClientes.Click += (s, e) => { new Clientes().Show(); this.Hide(); };
            this.btnEmpleados.Click += (s, e) => { new Usuarios().Show(); this.Hide(); };
            this.btnServicios.Click += (s, e) => { new GestionServicios().Show(); this.Hide(); };
            this.logOutButton.Click += (s, e) => { new Login().Show(); this.Hide(); };
        }

        private async void btnEliminarServicio_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtBoxIDEliminar.Text))
            {
                MessageBox.Show("Introduce el ID del servicio.", "Aviso");
                return;
            }

            // Convertir a Long (Java usa Long para IDs)
            if (!long.TryParse(txtBoxIDEliminar.Text, out long idServicio))
            {
                MessageBox.Show("El ID debe ser un número válido.", "Error");
                return;
            }

            DialogResult confirm = MessageBox.Show(
                $"¿Borrar servicio {idServicio}? Se perderá para siempre.", 
                "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (confirm == DialogResult.Yes)
            {
                // Llamada a la API que añadimos en el paso 1
                bool exito = await ApiClient.EliminarServicioAsync(idServicio);

                if (exito)
                {
                    MessageBox.Show("Servicio eliminado.", "Info");
                    new GestionServicios().Show(); // Volver a la lista
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Error al eliminar. Verifica que el ID exista.", "Error");
                }
            }
        }
    }
}