﻿using System;
using System.Windows.Forms;

namespace peluqueria
{
    public partial class AnyadirAdministradores : Form
    {
        public AnyadirAdministradores()
        {
            InitializeComponent();
            AsignarEventos();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.btnEmpleados.Text = "Usuarios"; 
        }

        private void AsignarEventos()
        {
            this.btnGuardarAdmin.Click += new EventHandler(btnGuardarAdmin_Click);

            // Navegación (CORREGIDO con this.Close())
            this.btnInicio.Click += (s, e) => { new Inicio().Show(); this.Close(); };
            this.btnClientes.Click += (s, e) => { new Clientes().Show(); this.Close(); };
            this.btnEmpleados.Click += (s, e) => { new Usuarios().Show(); this.Close(); };
            this.btnServicios.Click += (s, e) => { new GestionServicios().Show(); this.Close(); };
            this.logOutButton.Click += (s, e) => { new Login().Show(); this.Close(); };
        }

        private async void btnGuardarAdmin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtBoxUserNameAdmin.Text) ||
                string.IsNullOrWhiteSpace(txtBoxEmailAdmin.Text) || 
                string.IsNullOrWhiteSpace(txtBoxContraseñaAdmin.Text))
            {
                MessageBox.Show("Rellena todos los campos obligatorios.", "Atención");
                return;
            }

            bool exito = await ApiClient.RegistrarUsuarioAsync(
                txtBoxUserNameAdmin.Text,
                txtBoxEmailAdmin.Text,
                txtBoxContraseñaAdmin.Text,
                "admin" 
            );

            if (exito)
            {
                MessageBox.Show($"Administrador {txtBoxUserNameAdmin.Text} registrado.", "Éxito");
                new Usuarios().Show(); 
                this.Close(); // CORREGIDO: Cierra la ventana actual al finalizar
            }
            // Si hay error, la ventana se queda abierta para que el usuario corrija.
        }
    }
}