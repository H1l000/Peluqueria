﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace peluqueria
{
    public partial class AnyadirServicios : Form
    {
        public AnyadirServicios()
        {
            InitializeComponent();
            AsignarEventos();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void AsignarEventos()
        {
            this.btnGuardarServicio.Click += new EventHandler(btnGuardarServicio_Click);
            
            // Menú
            this.btnInicio.Click += (s, e) => { new Inicio().Show(); this.Hide(); };
            this.btnClientes.Click += (s, e) => { new Clientes().Show(); this.Hide(); };
            this.logOutButton.Click += (s, e) => { new Login().Show(); this.Hide(); };
            
            // Asumiendo que volver a servicios va a la lista
            this.btnServicios.Click += (s, e) => { 
                // new GestionServicios().Show(); 
                // this.Hide(); 
                MessageBox.Show("Ya estás en Servicios");
            };
        }

        private async void btnGuardarServicio_Click(object sender, EventArgs e)
        {
            // Validaciones
            if (string.IsNullOrWhiteSpace(txtBoxTituloServicio.Text) || 
                string.IsNullOrWhiteSpace(txtBoxBloqueDeTiempo.Text))
            {
                MessageBox.Show("El título y la duración son obligatorios.");
                return;
            }

            int duracion = 0;
            if(!int.TryParse(txtBoxBloqueDeTiempo.Text, out duracion))
            {
                MessageBox.Show("La duración debe ser un número entero (ej: 1, 2).");
                return;
            }

            // Construir el objeto para Java
            var nuevoServicio = new ApiClient.ServicioDTO
            {
                nombre = txtBoxTituloServicio.Text,
                descripcion = txtBoxDescripcion.Text,
                duracionBloques = duracion,
                // OJO: Tu Backend Java EXIGE precio (nullable=false). 
                // Como no vi TextBox de precio en tu diseño, pongo uno por defecto.
                // Deberías añadir un txtBoxPrecio al formulario.
                precio = 15.00 
            };

            // Nota: La imagen se ignora porque el Backend Java NO tiene campo para imagen.
            
            bool exito = await ApiClient.CrearServicioAsync(nuevoServicio);

            if (exito)
            {
                MessageBox.Show("Servicio creado correctamente en la Base de Datos.", "Éxito");
                txtBoxTituloServicio.Clear();
                txtBoxDescripcion.Clear();
                txtBoxBloqueDeTiempo.Clear();
                // Opcional: Volver al listado
            }
        }
    }
}