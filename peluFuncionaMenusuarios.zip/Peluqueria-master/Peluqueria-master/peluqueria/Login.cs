using System;
using System.Windows.Forms;

namespace peluqueria
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.AcceptButton = button1; // Permitir pulsar Enter para entrar
        }

        private void Login_Load(object sender, EventArgs e)
        {
            // Limpiar campos por seguridad
            txtBoxUsuario.Clear();
            txtBoxContrasenya.Clear();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            string user = txtBoxUsuario.Text;
            string pass = txtBoxContrasenya.Text;

            if (string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(pass))
            {
                MessageBox.Show("Introduce usuario y contraseña.", "Aviso");
                return;
            }

            // Feedback visual
            button1.Enabled = false;
            button1.Text = "Verificando...";

            // CONEXIÓN REAL CON JAVA
            bool loginExitoso = await ApiClient.LoginAsync(user, pass);

            button1.Enabled = true;
            button1.Text = "Iniciar Sesión";

            if (loginExitoso)
            {
                // Si todo va bien, vamos al Dashboard principal
                Inicio dashboard = new Inicio();
                dashboard.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Credenciales incorrectas o servidor apagado.", "Error Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}