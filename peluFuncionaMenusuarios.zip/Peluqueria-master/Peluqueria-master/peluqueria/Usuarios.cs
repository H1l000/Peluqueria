﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace peluqueria
{
    public partial class Usuarios : Form
    {
        public Usuarios()
        {
            InitializeComponent();
            AsignarEventos(); 
        }

        private void AsignarEventos()
        {
            // --- Botones de Acción ---
            this.btnAnyadirUsuario.Click += new EventHandler(btnAnyadirUsuario_Click);
            this.btnEditarUsuario.Click += new EventHandler(btnEditarUsuario_Click);
            this.btnEliminarUsuario.Click += new EventHandler(btnEliminarUsuario_Click);
            
            // --- ¡REFERENCIA A 'btnVolver' ELIMINADA PARA CORREGIR CS0103! ---

            // --- Navegación (Menú Izquierdo) ---
            this.btnInicio.Click += (s, e) => { new Inicio().Show(); this.Close(); };
            this.btnClientes.Click += (s, e) => { new Clientes().Show(); this.Close(); };
            this.btnEmpleados.Click += (s, e) => { new Usuarios().Show(); this.Close(); };
            this.btnServicios.Click += (s, e) => { new GestionServicios().Show(); this.Close(); };
            this.logOutButton.Click += (s, e) => { new Login().Show(); this.Close(); };
        }

        private async void Usuarios_Load(object sender, EventArgs e)
        {
            await CargarUsuarios();
        }

        private async Task CargarUsuarios()
        {
            try
            {
                var listaUsuarios = await ApiClient.GetUsuariosAsync();
                // dtGrdVwUsuarios.DataSource = listaUsuarios;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar usuarios: " + ex.Message);
            }
        }

        private void btnAnyadirUsuario_Click(object sender, EventArgs e)
        {
            EleccionAnyadirTipoUsuarios eleccion = new EleccionAnyadirTipoUsuarios();
            eleccion.ShowDialog();
            _ = CargarUsuarios(); 
        }

        private void btnEditarUsuario_Click(object sender, EventArgs e)
        {
            // Nota: Aquí se necesitaría el ID del DataGridView
            EditarUsuarios editar = new EditarUsuarios(); 
            editar.ShowDialog();
            _ = CargarUsuarios();
        }

        private void btnEliminarUsuario_Click(object sender, EventArgs e)
        {
            // Nota: Aquí se necesitaría el ID del DataGridView
            EliminarUsuario eliminar = new EliminarUsuario();
            eliminar.ShowDialog();
            _ = CargarUsuarios();
        }

        // --- MÉTODO 'btnVolver_Click' ELIMINADO PARA CORREGIR CS0103 ---
        // private void btnVolver_Click(object sender, EventArgs e)
        // {
        //     mainMenu menu = new mainMenu();
        //     this.Close(); 
        //     menu.Show();
        // }
    }
}