﻿namespace peluqueria
{
    partial class AnyadirCliente
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            // Declaración de componentes básicos (Mismo estilo que tenías)
            this.panelMenu = new System.Windows.Forms.Panel();
            this.logOutButton = new System.Windows.Forms.Button();
            this.btnClientes = new System.Windows.Forms.Button();
            this.btnEmpleados = new System.Windows.Forms.Button();
            this.btnServicios = new System.Windows.Forms.Button();
            this.btnInicio = new System.Windows.Forms.Button();
            this.panelArribaAnyadirClientes = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            
            // --- NUEVOS CAMPOS ---
            this.txtBoxNombreCliente = new System.Windows.Forms.TextBox(); // Username
            this.txtBoxEmailCliente = new System.Windows.Forms.TextBox();
            this.txtBoxContraseñaContrasenyaCliente = new System.Windows.Forms.TextBox();
            this.txtBoxDireccion = new System.Windows.Forms.TextBox(); // Nuevo
            this.txtBoxTelefono = new System.Windows.Forms.TextBox();   // Nuevo
            this.txtBoxAlergenos = new System.Windows.Forms.TextBox();  // Nuevo
            this.txtBoxAfecciones = new System.Windows.Forms.TextBox(); // Nuevo
            
            this.labelUsername = new System.Windows.Forms.Label();
            this.labelEmail = new System.Windows.Forms.Label();
            this.labelPass = new System.Windows.Forms.Label();
            this.labelDir = new System.Windows.Forms.Label();
            this.labelTel = new System.Windows.Forms.Label();
            this.labelAlg = new System.Windows.Forms.Label();
            this.labelAfc = new System.Windows.Forms.Label();
            
            this.btnGuardarCliente = new System.Windows.Forms.Button();

            // Configuración Panel Principal
            this.panelArribaAnyadirClientes.SuspendLayout();
            this.SuspendLayout();

            // Configuración simplificada de posiciones para que encaje todo
            int startX = 250; 
            int startY = 80;
            int gap = 50;

            // Username
            this.labelUsername.Text = "Nombre Usuario:";
            this.labelUsername.Location = new System.Drawing.Point(startX, startY);
            this.txtBoxNombreCliente.Location = new System.Drawing.Point(startX, startY + 20);
            this.txtBoxNombreCliente.Size = new System.Drawing.Size(200, 23);

            // Email
            this.labelEmail.Text = "Email:";
            this.labelEmail.Location = new System.Drawing.Point(startX, startY + gap);
            this.txtBoxEmailCliente.Location = new System.Drawing.Point(startX, startY + gap + 20);
            this.txtBoxEmailCliente.Size = new System.Drawing.Size(200, 23);

            // Password
            this.labelPass.Text = "Contraseña:";
            this.labelPass.Location = new System.Drawing.Point(startX, startY + gap * 2);
            this.txtBoxContraseñaContrasenyaCliente.Location = new System.Drawing.Point(startX, startY + gap * 2 + 20);
            this.txtBoxContraseñaContrasenyaCliente.Size = new System.Drawing.Size(200, 23);

            // -- NUEVOS --
            // Dirección
            this.labelDir.Text = "Dirección:";
            this.labelDir.Location = new System.Drawing.Point(startX + 250, startY);
            this.labelDir.AutoSize = true;
            this.txtBoxDireccion.Location = new System.Drawing.Point(startX + 250, startY + 20);
            this.txtBoxDireccion.Size = new System.Drawing.Size(200, 23);

            // Teléfono
            this.labelTel.Text = "Teléfono:";
            this.labelTel.Location = new System.Drawing.Point(startX + 250, startY + gap);
            this.labelTel.AutoSize = true;
            this.txtBoxTelefono.Location = new System.Drawing.Point(startX + 250, startY + gap + 20);
            this.txtBoxTelefono.Size = new System.Drawing.Size(200, 23);

            // Alérgenos
            this.labelAlg.Text = "Alérgenos:";
            this.labelAlg.Location = new System.Drawing.Point(startX, startY + gap * 3);
            this.labelAlg.AutoSize = true;
            this.txtBoxAlergenos.Location = new System.Drawing.Point(startX, startY + gap * 3 + 20);
            this.txtBoxAlergenos.Size = new System.Drawing.Size(450, 23); // Más largo

            // Afecciones
            this.labelAfc.Text = "Afecciones:";
            this.labelAfc.Location = new System.Drawing.Point(startX, startY + gap * 4);
            this.labelAfc.AutoSize = true;
            this.txtBoxAfecciones.Location = new System.Drawing.Point(startX, startY + gap * 4 + 20);
            this.txtBoxAfecciones.Size = new System.Drawing.Size(450, 23);

            // Botón Guardar
            this.btnGuardarCliente.Text = "GUARDAR CLIENTE";
            this.btnGuardarCliente.Location = new System.Drawing.Point(startX, startY + gap * 5 + 20);
            this.btnGuardarCliente.Size = new System.Drawing.Size(450, 40);
            this.btnGuardarCliente.BackColor = System.Drawing.Color.Black;
            this.btnGuardarCliente.ForeColor = System.Drawing.Color.White;

            // Panel Menu (Simplificado para el ejemplo)
            this.panelMenu.BackColor = System.Drawing.Color.Gray;
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Size = new System.Drawing.Size(200, 600);
            this.panelMenu.Controls.Add(this.btnInicio);
            this.panelMenu.Controls.Add(this.btnClientes);
            this.panelMenu.Controls.Add(this.btnEmpleados);
            this.panelMenu.Controls.Add(this.btnServicios);
            this.panelMenu.Controls.Add(this.logOutButton);

            // Botones Menú
            this.btnInicio.Text = "Inicio"; this.btnInicio.Top = 100; this.btnInicio.Width = 200; this.btnInicio.Height = 50;
            this.btnClientes.Text = "Clientes"; this.btnClientes.Top = 150; this.btnClientes.Width = 200; this.btnClientes.Height = 50;
            this.btnEmpleados.Text = "Usuarios"; this.btnEmpleados.Top = 200; this.btnEmpleados.Width = 200; this.btnEmpleados.Height = 50;
            this.btnServicios.Text = "Servicios"; this.btnServicios.Top = 250; this.btnServicios.Width = 200; this.btnServicios.Height = 50;
            this.logOutButton.Text = "Salir"; this.logOutButton.Top = 500; this.logOutButton.Width = 200; this.logOutButton.Height = 50;

            // Form
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.txtBoxNombreCliente);
            this.Controls.Add(this.txtBoxEmailCliente);
            this.Controls.Add(this.txtBoxContraseñaContrasenyaCliente);
            this.Controls.Add(this.txtBoxDireccion);
            this.Controls.Add(this.txtBoxTelefono);
            this.Controls.Add(this.txtBoxAlergenos);
            this.Controls.Add(this.txtBoxAfecciones);
            this.Controls.Add(this.labelUsername);
            this.Controls.Add(this.labelEmail);
            this.Controls.Add(this.labelPass);
            this.Controls.Add(this.labelDir);
            this.Controls.Add(this.labelTel);
            this.Controls.Add(this.labelAlg);
            this.Controls.Add(this.labelAfc);
            this.Controls.Add(this.btnGuardarCliente);
            this.Controls.Add(this.panelMenu);
            this.Name = "AnyadirCliente";
            this.Text = "Añadir Cliente";
            this.panelArribaAnyadirClientes.ResumeLayout(false);
            this.panelMenu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        // Controles públicos para acceder desde el .cs
        public System.Windows.Forms.TextBox txtBoxNombreCliente;
        public System.Windows.Forms.TextBox txtBoxEmailCliente;
        public System.Windows.Forms.TextBox txtBoxContraseñaContrasenyaCliente;
        public System.Windows.Forms.TextBox txtBoxDireccion;
        public System.Windows.Forms.TextBox txtBoxTelefono;
        public System.Windows.Forms.TextBox txtBoxAlergenos;
        public System.Windows.Forms.TextBox txtBoxAfecciones;
        
        private System.Windows.Forms.Panel panelMenu;
        public System.Windows.Forms.Button btnClientes;
        public System.Windows.Forms.Button logOutButton;
        public System.Windows.Forms.Button btnEmpleados;
        public System.Windows.Forms.Button btnServicios;
        public System.Windows.Forms.Button btnInicio;
        private System.Windows.Forms.Panel panelArribaAnyadirClientes;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Button btnGuardarCliente;
        private System.Windows.Forms.Label labelUsername;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.Label labelPass;
        private System.Windows.Forms.Label labelDir;
        private System.Windows.Forms.Label labelTel;
        private System.Windows.Forms.Label labelAlg;
        private System.Windows.Forms.Label labelAfc;
    }
}